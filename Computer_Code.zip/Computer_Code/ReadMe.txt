Manuscript Title: Coding 3D Seismic Data Visualization in C++, OpenGL and GLSL
Name of code: GnGAnalyzer
Developer: Farhan Naseer
Contact address: 16300 Park Row Dr, Houston, TX 77084
Telephone Number: +1361 437 0851
Email: farhannaseer78@gmail.com
Year first available: 2023
Hardware required: Graphical Processing Unit
Software required: Windows 10, Qt 5.15
Program language: C++, OpenGL, GLSL
Program size: 1.25 MB (code only). 13.8MB (Code + example data)
Source Code Access: https://github.com/farhan-admin/GnGAnalyzer
